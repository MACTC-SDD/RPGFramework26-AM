﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPGFramework.MapObjects
{
    public class Builder
    {
        public static bool ProcessCommand(Character character, List<string> parameters)
        {
            // It only makes sense for players to use builder commands (for now).
            if (!(character is Player))
                return false;

            Player player = (Player)character;
            
            switch (parameters[0].ToLower())
            {
                case "/room":
                    RoomCommand(player, parameters);
                    return true;
            }

            return false;
        }

        private static void RoomCommand(Player player, List<string> parameters)
        {
            if (parameters.Count < 2)
            {
                // Write help message.
                player.WriteLine("Usage: ");
                player.WriteLine("/room desription <set room desc to this>");
                return;
            }            

            switch (parameters[1].ToLower())
            {
                // Probably this should be a separate method.
                case "description":
                    RoomSetDescription(player, parameters);
                    break;
            }            
        }

        /// <summary>
        /// Set description of a room, or just display it if no new description provided.
        /// </summary>
        /// <param name="player"></param>
        /// <param name="parameters"></param>
        private static void RoomSetDescription(Player player, List<string> parameters)
        {
            if (!Utility.CheckPermission(player, PlayerRole.Admin))
            {
                player.WriteLine("You do not have permission to do that.");
                return;
            }

            if (parameters.Count < 3)
            {
                player.WriteLine($"{player.GetRoom().Description}");
            }
            else
            {
                player.GetRoom().Description = parameters[2];
            }
        }

        private static void SetRoomName(Player player, List<string> parameters)
        {
            if (parameters.Count < 3)
            {
                player.WriteLine($"{player.GetRoom().Name}");
            }
            else
            {
                player.GetRoom().Name = parameters[2];
            }
        }
    }
}
