﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPGFramework.MapObjects
{
    public class Room
    {
        #region --- Properties ---
        // Unique identifier for the room
        public int Id { get; set; } = 0;

        // What area this belongs to 
        public int AreaId { get; set; } = 0;

        // Name of the room
        public string Name { get; set; } = "";

        // Description of the room
        public string Description { get; set; } = "";

        // List of exits from the room
        public List<int> ExitIds { get; set; } = new List<int>();
        #endregion --- Properties ---

        #region --- Methods ---

        /// <summary>
        /// Return a list of Exit objects that are in this room.
        /// </summary>
        /// <returns></returns>
        public List<Exit> GetExits()
        {
            // This works just like the loop in GetPlaysersInRoom, but is shorter
            // This style of list maniuplation is called "LINQ"
            return GameState.Instance.Areas[AreaId].Exits.Values
                .Where(e => e.SourceRoomId == Id).ToList();
        }

        /// <summary>
        /// Return a list of Player objects that are in this room.
        /// </summary>
        /// <note>
        /// We have both an instance method (GetPlayers) and a static method (GetPlayersInRoom) that do the same thing.
        /// </note>
        /// <returns></returns>
        public List<Player> GetPlayers()
        {
            return GetPlayersInRoom(this);
        }

        /// <summary>
        /// Return a list of player objects that are in the specified room
        /// </summary>
        /// <param name="room"></param>
        /// <returns></returns>
        public static List<Player> GetPlayersInRoom(Room room)
        {
            // Loop through GameState.ConnectedPlayers and return a list of players in the room
            List<Player> playersInRoom = new List<Player>();
            foreach (Player p in GameState.Instance.Players.Values)
            {
                if (p.IsOnline 
                    && p.AreaId == room.AreaId 
                    && p.LocationId == room.Id)
                {
                    playersInRoom.Add(p);
                }
            }

            return playersInRoom;
        }
        #endregion --- Methods ---

        #region --- Methods (Events) ---
        /// <summary>
        /// When a character enters a room, do this.
        /// </summary>
        /// <param name="character"></param>
        public void EnterRoom(Character character, Room fromRoom)
        {
            // Send a message to the player
            if (character is Player) ((Player)character).WriteLine(Description);

            // Send a message to all players in the room
            Comm.SendToRoomExcept(this, $"{character.Name} enters the room.", character);
        }

        /// <summary>
        /// When a character leaves a room, do this.
        /// </summary>
        /// <param name="character"></param>
        /// <param name="toRoom"></param>
        public void LeaveRoom(Character character, Room toRoom)
        {
           // Send a message to all players in the room
            Comm.SendToRoomExcept(this, $"{character.Name} leaves the room.", character);
        }
        #endregion
    }
}
