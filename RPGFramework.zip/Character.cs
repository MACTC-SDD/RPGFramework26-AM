﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RPGFramework.MapObjects;

namespace RPGFramework
{
    // Probably abstratt
    // This is meant to hold all of the commmon elements for
    // players, NPCs, etc.
    public class Character
    {
        public int AreaId { get; set; } = 0;

        public int Health { get; set; } = 0;
        public int LocationId { get; set; } = 0;
        public int MaxHealth { get; set; } = 0;
        public string Name { get; set; } = "";
        public int XP { get; set; } = 0;

        /// <summary>
        /// Get Room object of current location.
        /// </summary>
        /// <returns></returns>
        public Room GetRoom()
        {
            return GameState.Instance.Areas[AreaId].Rooms[AreaId];
        }
    }
}
