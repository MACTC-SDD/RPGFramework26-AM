﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RPGFramework
{
    public class ObjectStorage
    {
        public static void SaveObject<T>(T obj, string path, string fileName)
        {
            try
            {
                path = Path.Combine(AppContext.BaseDirectory, path);

                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                string filePath = Path.Combine(path, fileName);

                JsonSerializerOptions options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string jsonString = JsonSerializer.Serialize(obj, options);
                File.WriteAllText(filePath, jsonString);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving object: {ex.Message}");
            }
        }

        public static T LoadObject<T>(string path, string fileName)
        {
            path = Path.Combine(AppContext.BaseDirectory, path);
            string filePath = Path.Combine(path, fileName);

            
            if (!File.Exists(filePath))
                throw new FileNotFoundException(
                    $"The file '{fileName}' doesn't exist in the directory '{filePath}'");


            string jsonString = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<T>(jsonString);
        }

        // Load all objects of a given type from a directory
        public static List<T> LoadAllObjects<T>(string path)
        {
            path = Path.Combine(AppContext.BaseDirectory, path);

            if (!Directory.Exists(path))
                throw new DirectoryNotFoundException($"The directory '{path}' doesn't exist");

            List<T> objects = new List<T>();

            foreach (string file in Directory.EnumerateFiles(path))
            {
                string jsonString = File.ReadAllText(file);
                objects.Add(JsonSerializer.Deserialize<T>(jsonString));
            }

            return objects;
        }
    }
}
