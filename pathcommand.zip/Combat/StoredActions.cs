﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPGFramework.data_seed.COmbat_Team
{


    public class DeclaredAction
    {
        //string PlayerName = Character.Name;
        //int Dexterity = Character.Dexterity;
        //int attack = blank.blank
        //string item = blank.blank
        //int heal  = blank.blank
        // int parry = blank.blank
        //int specialAttack  = blank.blank
    }

}
