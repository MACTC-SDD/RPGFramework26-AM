﻿namespace RPGFramework.Enums
{
    internal enum BattleState
    {
        Combat,
        CombatComplete,
    }
}
