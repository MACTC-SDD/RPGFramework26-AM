namespace RPGFramework.Enums
{
    internal enum ArmorMaterial
    {
        Cloth,
        Bronze,
        Bone,
        Rusty,
        DragonScale,
        EnchantedSteel,
        Crystal,
        Leather,
        Iron,
        Steel,
        Mythril,
        Obsidian,
        Tungsten,
        StarMetal,
        MeteorSteel,
        VoidStone,
        MoonSilver
    }
}
    
