﻿
namespace RPGFramework.Enums
{
    internal enum DebugLevel
    {
        Error,
        Warning,
        Alert,
        Info,
        Debug
    }
}
