﻿namespace RPGFramework.Enums
{
    internal enum NonPlayerType
    {
        Default,
        Mob,
        Shopkeep,
        QuestGiver,
        Trainer,
    }
}