﻿namespace RPGFramework
{
    internal interface IDescribable
    {
        string Description { get; set; }
    }
}
