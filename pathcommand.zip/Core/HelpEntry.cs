﻿namespace RPGFramework
{
    internal class HelpEntry
    {
        public required string Topic { get; set; }
        public required string Category { get; set; }
        public required string Content { get; set; }

    }
}
