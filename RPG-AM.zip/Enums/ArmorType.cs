﻿
namespace RPGFramework.Enums
{
    internal enum ArmorType
    {
        Light,
        Medium,
        Heavy
    }
}
    
