﻿
namespace RPGFramework.Enums
{
    internal enum ArmorSlot
    {
        Head,
        Chest,
        Legs,
        Back
    }
}
    
