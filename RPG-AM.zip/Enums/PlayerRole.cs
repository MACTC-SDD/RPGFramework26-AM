﻿
namespace RPGFramework.Enums
{
    internal enum PlayerRole
    {
        Player,
        Builder,
        Admin,
        God
    }
}
