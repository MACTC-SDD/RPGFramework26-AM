﻿namespace RPGFramework.Enums
{
    public enum ExitType
    {
        Open,
        Door,
        LockedDoor,
        Impassable
    }
}
