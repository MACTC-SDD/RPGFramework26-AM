﻿
namespace RPGFramework.Enums
{
    internal enum Direction
    {
        North,
        South,
        East,
        West,
        Up,
        Down,
        None
    }
}
