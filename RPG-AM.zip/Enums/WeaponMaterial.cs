﻿
namespace RPGFramework.Enums
{
    internal enum WeaponMaterial
    {
        Wood,
        Bone,
        Rusty,
        Stone,
        Iron,
        Steel,
        Mythril,
        Obsidian,
        Copper,
        Bronze,
        DragonBone,
        Crystal,
        Tungsten,
        VoidMetal,
        StarMetal,
        Gold,
        Basalt,
        MoonSilver,
        
    }
}
    
