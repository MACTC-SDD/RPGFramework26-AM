﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPGFramework
{
    internal interface IDescribable
    {
        string Description { get; set; }
    }
}
